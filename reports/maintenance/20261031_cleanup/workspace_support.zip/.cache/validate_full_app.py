from pathlib import Path
import json

import numpy as np
import pandas as pd
import requests

from src.data.contracts import invalid_candle_mask
from src.models.inference import ModelService

r = Path.cwd()
service = ModelService(r)
base = 'http://127.0.0.1:8000'
results = []
for name in ['LSTM', 'Train Mean', 'Zero-Return', 'Ridge', 'XGBoost']:
    response = requests.post(base + '/api/v1/predict', json={'model': name}, timeout=60)
    response.raise_for_status()
    online, offline = response.json(), service.predict(name)
    assert online['model_version'] == service.manifest['run_id']
    assert np.isclose(online['predicted_log_return'], offline['predicted_log_return'], atol=1e-8)
    results.append({'model': name, 'api_matches_offline': True, 'prediction': online})
raw = pd.read_csv(r / 'data/raw/FPT.VN_raw.csv')
raw = raw.loc[raw.Volume.gt(0) & ~invalid_candle_mask(raw)].copy()
rows = raw.rename(columns={'Date': 'date', 'Open': 'open', 'High': 'high', 'Low': 'low',
                           'Close': 'close', 'Volume': 'volume'}).to_dict('records')
sample = requests.post(base + '/api/v1/predict', json={'model': 'LSTM', 'observations': rows}, timeout=60)
sample.raise_for_status()
assert np.isclose(sample.json()['predicted_log_return'], service.predict('LSTM')['predicted_log_return'], atol=1e-8)
assert requests.post(base + '/api/v1/predict', json={'ticker': 'PNJ.VN'}, timeout=30).status_code == 422
assert requests.post(base + '/api/v1/predict', json={'observations': rows[-51:]}, timeout=30).status_code == 422
assert requests.get(base + '/docs', timeout=30).status_code == 200
assert requests.get(base + '/api/v1/metrics', timeout=30).json()['metrics'][0]['hit_rate_pct'] is None
print('Real model API checks passed.', flush=True)

from streamlit.testing.v1 import AppTest
app = AppTest.from_file(str(r / 'src/app/streamlit_app.py'), default_timeout=60).run()
assert not app.exception, [str(e) for e in app.exception]
app.button[0].click().run()
assert not app.exception, [str(e) for e in app.exception]
assert len(app.metric) == 3
app.selectbox[0].select('Train Mean').run()
app.button[0].click().run()
assert not app.exception, [str(e) for e in app.exception]
assert len(app.metric) == 3
out = r / 'reports/verification'
out.mkdir(parents=True, exist_ok=True)
(out / 'api_ui_smoke.json').write_text(json.dumps({
    'run_id': service.manifest['run_id'], 'api_checks': results,
    'full_ohlcv_sample_matches_snapshot_prediction': True,
    'invalid_requests_rejected': True, 'swagger_ok': True,
    'streamlit_load_and_predict_lstm_and_train_mean': True,
}, indent=2), encoding='utf-8')
print('Streamlit HTTP integration checks passed.', flush=True)
