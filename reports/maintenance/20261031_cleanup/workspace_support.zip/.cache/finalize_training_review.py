from pathlib import Path
import hashlib
import json
import zipfile

import nbformat
import pandas as pd
from nbconvert import HTMLExporter

r = Path.cwd()
p = json.loads((r / 'models/latest_experiment.json').read_text())
a, d = r / p['artifact_dir'], r / p['report_dir']
m = json.loads((a / 'manifest.json').read_text())
scores = pd.read_csv(d / 'metrics.csv')
val = scores.loc[scores['split'].eq('validation')].set_index('model')
test = scores.loc[scores['split'].eq('test')].set_index('model')
lines = [
    '# Kết quả kiểm tra và huấn luyện FPT v2', '',
    f"Lượt chạy `{p['run_id']}`, CPU, TensorFlow {m['runtime']['tensorflow']}, seed 42. "
    'Không dùng Colab vì dữ liệu và kiến trúc hiện tại chạy được trên máy local.', '',
    '## Kết luận', '',
    '- Baseline Train Mean có validation RMSE thấp nhất toàn bộ nhóm. Đây là lựa chọn của quy tắc đã khóa, không đổi sang model khác sau khi xem test.',
    '- Trong nhóm mô hình học máy được thử, LSTM lookback 30 có validation RMSE thấp nhất. Trên test lịch sử, RMSE LSTM chỉ tốt hơn zero-return rất nhẹ; MAE lại cao hơn.',
    '- Hit Rate LSTM 54,98% trên 211 quan sát thực tế không đứng giá; 37 ngày đứng giá được báo riêng. Mốc always-down hậu nghiệm cũng đạt 54,98%, dù các quyết định của LSTM khác. Không dùng con số 55% để khẳng định lợi thế thống kê hay lợi nhuận.',
    '- Năm 2025 đã được xem trong lần thử trước: đây là đánh giá lịch sử sử dụng lại, chưa phải kiểm chứng trên holdout hoàn toàn mới.', '',
    '## Bảng kết quả', '',
    '| Model | Validation RMSE | Test RMSE | Test MAE | Test Hit Rate |',
    '| --- | ---: | ---: | ---: | ---: |',
]
for name in test.index:
    t, v = test.loc[name], val.loc[name]
    hit = 'N/A' if pd.isna(t['hit_rate_pct']) else f"{t['hit_rate_pct']:.2f}%"
    lines.append(f"| {name} | {v['rmse']:.6f} | {t['rmse']:.6f} | {t['mae']:.6f} | {hit} |")
lines += ['', 'RMSE/MAE tính trên log return. Directional accuracy dùng cùng mẫu actual khác 0; dự báo 0 không được bỏ để làm tăng score. Zero-return không đưa ra hướng nên có Hit Rate N/A.', '',
          '## Các lỗi đã sửa', '',
          '- Dùng chung lịch split có chặn target date và cùng ngày mẫu cho baseline/LSTM/lookback.',
          '- LSTM lấy context từ features đầy đủ, cửa sổ bao gồm đúng ngày dự báo. Không bỏ phần đầu validation/test vì lookback.',
          '- Scaler và mô hình chỉ fit trên train; chọn alpha, độ sâu và lookback trên validation. Không đánh giá test từng trial.',
          '- Loại Hit Rate 50% giả của zero-return; ghi coverage và số actual đứng giá.',
          '- Mỗi lượt train có thư mục riêng; manifest gắn chính xác model/scaler, feature order, data/weight hashes, môi trường và cấu hình.',
          '- Notebook 03 nạp đúng artifact và tính lại metrics để đối chiếu. Không trộn tên alias cũ và metadata từ lượt khác.', '',
          '## Kiểm chứng', '',
          '- 21 unit test đã qua, gồm dữ liệu, target-date boundary, sequence và metrics.',
          '- Notebook 02 và 03 đã chạy từ đầu, không có cell lỗi, có outputs và biểu đồ được kiểm tra.',
          '- Dataset đang có được kiểm tra bằng hash; không tải lại nguồn khi training.',
          '- Đã nạp lại model/scaler trong process mới; RMSE/MAE khớp manifest. Công thức metric chính được đối chiếu độc lập từ predictions CSV.', '',
          '## Cách chạy lại', '', '```powershell',
          'python -m src.models.experiment --epochs 40 --seed 42',
          'python -m unittest discover -s tests -v', '```', '',
          'Trên Colab: giải nén gói cùng snapshot vào `/content/Stock_Prediction_Project`, cài dependency còn thiếu (đặc biệt `ta`, `xgboost`), mở notebook 02 rồi 03. Có thể giữ TensorFlow do Colab cung cấp; phiên bản khác có thể cho kết quả số khác nhẹ. Lưu outputs/artifact về Drive. File `requirements-lock.txt` ghi môi trường Windows của lượt local, không phải lock dùng nguyên trạng cho Linux/Colab.', '',
          '## Nguồn của kết quả mới', '',
          f"- [Manifest](../{p['artifact_dir']}/manifest.json)",
          f"- [Metrics đầy đủ](../{p['report_dir']}/metrics.csv)",
          f"- [Dự báo kèm origin/target date](../{p['report_dir']}/predictions.csv)",
          f"- [Lựa chọn trên validation](../{p['report_dir']}/selection.json)",
          f"- [Chẩn đoán tăng/giảm](../{p['report_dir']}/direction_diagnostics.csv)",
          '- [Notebook training](../notebooks/02_train_deep_learning_fpt.ipynb)',
          '- [Notebook kiểm chứng](../notebooks/03_evaluate_fpt_benchmark.ipynb)', '',
          '## Giới hạn còn lại', '',
          'Chưa có walk-forward, ablation nhóm đặc trưng, kiểm chứng point-in-time/calendar độc lập hoặc backtest có thực thi giao dịch. Notebook dashboard 04 và API/UI chưa được nối với manifest mới; source và output cũ của chúng được giữ. Không dùng bảng `reports/figures` cũ thay cho kết quả trong thư mục experiment này.', '']
(r / 'docs/TRAINING_RESULTS.md').write_text('\n'.join(lines), encoding='utf-8')

preview = r / '.cache/notebook-preview'
preview.mkdir(parents=True, exist_ok=True)
for name in ['02_train_deep_learning_fpt', '03_evaluate_fpt_benchmark']:
    notebook = nbformat.read(r / 'notebooks' / (name + '.ipynb'), as_version=4)
    nbformat.validate(notebook)
    assert not [o for c in notebook.cells for o in c.get('outputs', []) if o['output_type'] == 'error']
    html, _ = HTMLExporter().from_notebook_node(notebook)
    (preview / (name + '.html')).write_text(html, encoding='utf-8')

bundle = r / 'data/backups' / f"colab-fpt-v2-{p['run_id']}.zip"
paths = [r / 'requirements.txt', r / 'README.md', *r.glob('src/**/*.py'),
         *r.glob('tests/*.py'), *r.glob('docs/*.md'), *r.glob('docs/assets/*.svg'),
         *r.glob('data/raw/FPT.VN_*'), *r.glob('data/interim/FPT.VN_*'),
         *r.glob('data/processed/FPT.VN_*'),
         r / 'notebooks/02_train_deep_learning_fpt.ipynb', r / 'notebooks/03_evaluate_fpt_benchmark.ipynb']
with zipfile.ZipFile(bundle, 'x', zipfile.ZIP_DEFLATED) as z:
    for path in paths:
        if path.is_file():
            z.write(path, 'Stock_Prediction_Project/' + path.relative_to(r).as_posix())
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    for path in [r / 'data/interim/FPT.VN_features.csv', r / 'data/processed/FPT.VN_supervised.csv']:
        data = z.read('Stock_Prediction_Project/' + path.relative_to(r).as_posix())
        assert hashlib.sha256(data).hexdigest() == hashlib.sha256(path.read_bytes()).hexdigest()
print('Training notes, HTML previews and verified Colab snapshot bundle:', bundle)
