from pathlib import Path
import nbformat as nbf

root = Path.cwd()
md = nbf.v4.new_markdown_cell
code = nbf.v4.new_code_cell
setup = '''from pathlib import Path
import os, sys, json

candidates = [Path(os.environ.get('FPT_PROJECT_ROOT', Path.cwd())), Path.cwd(),
              *Path.cwd().parents, Path('/content/Stock_Prediction_Project')]
ROOT = next((p for p in candidates if (p / 'src/models/experiment.py').exists()), None)
if ROOT is None:
    raise FileNotFoundError('Open/upload the UPDATED project, including src/models/experiment.py; set FPT_PROJECT_ROOT if needed.')
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, Markdown
from src.models.experiment import load_data, split_masks, run_experiment, evaluate_saved
from src.features.build_features import FEATURE_COLUMNS, TARGET_COLUMN
plt.rcParams.update({'figure.figsize': (11, 4), 'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
print('Project:', ROOT)
'''

train = nbf.v4.new_notebook(cells=[
    md('''# Huấn luyện FPT v2: baseline và LSTM

Notebook này gọi cùng module `src/models/experiment.py` trên local hoặc Colab.
Chỉ dùng snapshot CSV có hash khớp metadata; không tự tải dữ liệu mới khi thiếu file.

**Colab:** giải nén gói project vào `/content/Stock_Prediction_Project`, cài dependency trong `requirements.txt`, rồi mở notebook. Chọn GPU nếu muốn; CPU cũng chạy được. Copy thư mục `models/experiments/<run_id>` và `reports/experiments/<run_id>` về Drive sau khi chạy.

**Lưu ý thực nghiệm:** năm 2025 đã được xem trong lần thử trước. Kết quả dưới đây là đánh giá lịch sử được sử dụng lại, không gọi là holdout hoàn toàn chưa từng xem.'''),
    md('## Kết quả chính\nCác số liệu sẽ được điền sau khi chạy và kiểm tra notebook.'),
    md('## 1. Môi trường và nguồn dữ liệu'), code(setup),
    code('''features, labels, data_metadata = load_data(ROOT)
masks = split_masks(labels)
display(pd.DataFrame([
    {'split': name, 'samples': int(mask.sum()),
     'origin_start': labels.loc[mask, 'Date'].min(),
     'origin_end': labels.loc[mask, 'Date'].max(),
     'last_target': labels.loc[mask, 'Target_Date_1d'].max()}
    for name, mask in masks.items()
]))
print('Inputs:', len(FEATURE_COLUMNS), '| Raw SHA256:', data_metadata['source_raw_sha256'])
print('All models use the same eligible dates and at least 60 rows of past context.')'''),
    md('''## 2. Phương pháp và lựa chọn cấu hình

- Train tới 2022; validation 2023–2024; test 2025. Nhãn vượt ranh giới bị loại.
- Cửa sổ LSTM bao gồm ngày dự báo, lấy từ lịch sử features đầy đủ.
- Scaler fit trên lịch sử train; mọi model dùng chung ngày train/validation/test.
- So sánh zero-return, persistence-return, train-mean, always-up, LR, Ridge, XGBoost và LSTM.
- Ridge thử 3 alpha; XGBoost thử 2 độ sâu; LSTM thử lookback 10/30/60, một lớp 32 units.
- Chọn theo **validation RMSE**; ghi `selection.json` trước khi dự đoán test. Không xem test từng trial.
- Zero-return có directional accuracy **N/A**, không gán 50%. Ngày thực tế đứng giá được báo riêng; dự báo 0 không giúp tăng accuracy bằng cách bỏ mẫu.'''),
    code('''EPOCHS = 40
SEED = 42
result = run_experiment(ROOT, include_lstm=True, epochs=EPOCHS, seed=SEED)
REPORT_DIR = ROOT / result['report_dir']
ARTIFACT_DIR = ROOT / result['artifact_dir']
manifest = result['manifest']
scores = result['metrics']
print('Artifacts:', ARTIFACT_DIR)
print('Reports:', REPORT_DIR)'''),
    md('## 3. Validation và ablation lookback'),
    code('''trials = pd.read_csv(REPORT_DIR / 'validation_trials.csv')
display(trials[['candidate', 'family', 'rmse', 'mae', 'hit_rate_pct', 'direction_coverage_pct']])
fig, ax = plt.subplots(figsize=(11, 5))
ax.barh(trials['candidate'], trials['rmse'], color='#2563eb')
zero_rmse = float(trials.loc[trials['candidate'].eq('Zero-Return'), 'rmse'].iloc[0])
ax.axvline(zero_rmse, color='#dc2626', linestyle='--', label='Zero-return baseline')
ax.set(xlabel='Validation RMSE (log return)', title='FPT: candidate selection uses validation only', xlim=(0, None))
ax.legend()
fig.tight_layout()
fig.savefig(REPORT_DIR / 'validation_candidates.png', dpi=160)
plt.show()'''),
    code('''histories = json.loads((REPORT_DIR / 'lstm_history.json').read_text())
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
for lb, history in histories.items():
    for ax, metric in zip(axes, ['loss', 'val_loss']):
        ax.plot(np.arange(1, len(history[metric]) + 1), history[metric], label=f'lookback {lb}')
for ax, title in zip(axes, ['Training Huber loss', 'Validation Huber loss']):
    ax.set(xlabel='Epoch', ylabel='Loss on standardized target', title=title)
    ax.legend()
fig.tight_layout()
fig.savefig(REPORT_DIR / 'learning_curves.png', dpi=160)
plt.show()'''),
    md('## 4. Cấu hình đã khóa và đánh giá test lịch sử'),
    code('''display(pd.Series(manifest['selection']))
display(scores.loc[scores['split'].eq('test'),
    ['model', 'n', 'rmse', 'mae', 'hit_rate_pct', 'direction_coverage_pct', 'mse_skill_vs_zero']])
print('Negative MSE skill means worse than predicting zero return.')'''),
    md('## 5. Diễn giải và bàn giao artifact'),
    code('''selected = manifest['selection']['selected_model']
selected_test = scores.loc[scores['split'].eq('test') & scores['model'].eq(selected)].iloc[0]
zero_test = scores.loc[scores['split'].eq('test') & scores['model'].eq('Zero-Return')].iloc[0]
display(Markdown(
    f"Model được chọn trên validation: **{selected}**. "
    f"Test RMSE = **{selected_test['rmse']:.6f}**, zero-return = **{zero_test['rmse']:.6f}**. "
    f"MSE skill = **{selected_test['mse_skill_vs_zero']:.2%}**. "
    "Không kết luận lợi nhuận giao dịch từ các chỉ số này. "
    "Manifest lưu model/scaler, seed, feature order, hash dữ liệu/artifact và phiên bản thư viện."
))
print('Run ID:', result['run_id'])'''),
])

evaluate = nbf.v4.new_notebook(cells=[
    md('''# Kiểm chứng artifact và benchmark FPT v2

Notebook chỉ nạp artifact của lượt train đã khóa, **không huấn luyện và không chọn lại bằng test**.
Kiểm tra hash dữ liệu/weights và đối chiếu metrics tính lại với manifest.
Năm 2025 là đánh giá lịch sử đã được xem trong các lần thử trước.'''),
    md('## 1. Nạp lượt chạy đã lưu'), code(setup),
    code('''pointer = json.loads((ROOT / 'models/latest_experiment.json').read_text())
ARTIFACT_DIR, REPORT_DIR = ROOT / pointer['artifact_dir'], ROOT / pointer['report_dir']
manifest = json.loads((ARTIFACT_DIR / 'manifest.json').read_text())
scores, predictions = evaluate_saved(ARTIFACT_DIR, ROOT, verify_recorded=True)
display(scores)
print('Reloaded metrics match the saved record:', pointer['run_id'])'''),
    md('## 2. Sai số và độ chính xác chiều tăng/giảm'),
    code('''names = scores.loc[scores['split'].eq('validation'), 'model'].tolist()
val = scores.loc[scores['split'].eq('validation')].set_index('model').loc[names]
test = scores.loc[scores['split'].eq('test')].set_index('model').loc[names]
x = np.arange(len(names))
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
for ax, metric, title in [(axes[0], 'rmse', 'RMSE (log return)'),
                          (axes[1], 'hit_rate_pct', 'Direction accuracy on nonzero actuals (%)')]:
    ax.bar(x - .18, val[metric], .36, label='Validation 2023-2024', color='#2563eb')
    ax.bar(x + .18, test[metric], .36, label='Historical test 2025', color='#d97706')
    ax.set_xticks(x, names, rotation=40, ha='right')
    ax.set_title(title)
    ax.set_ylim(bottom=0)
    ax.legend()
axes[1].set_ylim(0, 100)
axes[1].text(0.02, .96, 'Zero-return: N/A (no directional forecasts)', transform=axes[1].transAxes, va='top')
fig.tight_layout()
fig.savefig(REPORT_DIR / 'benchmark.png', dpi=160)
plt.show()'''),
    md('## 3. Phân tích lỗi theo thời gian'),
    code('''chosen = manifest['selection']['selected_model']
frame = predictions.loc[predictions['split'].eq('test') & predictions['model'].eq(chosen)].copy()
fig, ax = plt.subplots(figsize=(12, 4))
ax.plot(pd.to_datetime(frame['Target_Date_1d']), frame[TARGET_COLUMN] * 100,
        label='Actual', color='#64748b', linewidth=1)
ax.plot(pd.to_datetime(frame['Target_Date_1d']), frame['predicted_log_return'] * 100,
        label=chosen, color='#2563eb', linewidth=1)
ax.axhline(0, color='#111827', linewidth=.7)
ax.set(xlabel='Target date', ylabel='Log return × 100', title='Historical test: actual vs validation-selected prediction')
ax.legend()
fig.tight_layout()
fig.savefig(REPORT_DIR / 'test_returns.png', dpi=160)
plt.show()
frame['absolute_error'] = abs(frame[TARGET_COLUMN] - frame['predicted_log_return'])
display(frame.nlargest(10, 'absolute_error')[['Date', 'Target_Date_1d', TARGET_COLUMN, 'predicted_log_return', 'absolute_error']])'''),
    md('''## Giới hạn

- Giá điều chỉnh tải sau thời kỳ nghiên cứu; lịch phiên chưa xác minh độc lập với HOSE.
- Không gọi 2025 là test hoàn toàn chưa từng xem.
- Directional accuracy không phải xác suất đúng của mỗi dự báo, không chứng minh hiệu quả giao dịch.
- Một lần chia lịch sử chưa chứng minh khả năng tổng quát ở mọi giai đoạn; walk-forward là bước tiếp theo.
- `reports/figures` cũ không phải nguồn cho các con số của lượt chạy mới.'''),
])
for name, notebook in [('02_train_deep_learning_fpt.ipynb', train), ('03_evaluate_fpt_benchmark.ipynb', evaluate)]:
    notebook.metadata.kernelspec = {'display_name': 'Python 3 (ipykernel)', 'language': 'python', 'name': 'python3'}
    nbf.validate(notebook)
    nbf.write(notebook, root / 'notebooks' / name)
    print('Updated:', name)
