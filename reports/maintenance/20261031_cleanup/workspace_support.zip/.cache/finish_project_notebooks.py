from pathlib import Path
import nbformat as nbf

r = Path.cwd()
md, code = nbf.v4.new_markdown_cell, nbf.v4.new_code_cell
setup = '''from pathlib import Path
import os, sys, json, subprocess, importlib.metadata
try:
    import google.colab
    IN_COLAB = True
except ImportError:
    IN_COLAB = False
if IN_COLAB:
    ROOT = Path('/content/Stock_Prediction_Project_v2')
    if not (ROOT / '.git').exists():
        subprocess.check_call(['git', 'clone', '--depth', '1', '--branch', 'feature/train-model',
                               'https://github.com/PhucTruong11/Stock_Prediction_Project.git', str(ROOT)])
    loaded_versions = {name: getattr(sys.modules.get(name), '__version__', None)
                       for name in ['numpy', 'pandas', 'sklearn', 'tensorflow', 'xgboost']}
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-q', '-r', str(ROOT / 'requirements-colab.txt')])
    packages = {'sklearn': 'scikit-learn', 'numpy': 'numpy', 'pandas': 'pandas', 'tensorflow': 'tensorflow', 'xgboost': 'xgboost'}
    changed = [name for name, old in loaded_versions.items()
               if old is not None and old != importlib.metadata.version(packages[name])]
    if changed:
        raise RuntimeError('Dependencies changed: ' + str(changed) + '. Restart the Colab session, then Run all again.')
else:
    candidates = [Path(os.environ.get('FPT_PROJECT_ROOT', Path.cwd())), Path.cwd(), *Path.cwd().parents]
    ROOT = next((p for p in candidates if (p / 'src/models/experiment.py').exists()), None)
if ROOT is None:
    raise FileNotFoundError('Open the complete updated project.')
os.chdir(ROOT)
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from src.data.snapshot import restore_snapshot
restore_snapshot(ROOT)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, Markdown
from src.models.experiment import load_data, split_masks, run_experiment, evaluate_saved
from src.features.build_features import FEATURE_COLUMNS, TARGET_COLUMN
plt.rcParams.update({'figure.figsize': (11, 4), 'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
print('Project:', ROOT)
print('Exact shared snapshot restored; no Yahoo download.')
'''

for name in ['02_train_deep_learning_fpt.ipynb', '03_evaluate_fpt_benchmark.ipynb']:
    p = r / 'notebooks' / name
    n = nbf.read(p, as_version=4)
    for cell in n.cells:
        if cell.cell_type == 'code' and 'candidates = [' in cell.source and 'FPT_PROJECT_ROOT' in cell.source:
            cell.source = setup
    n.cells[0].source += '\n\n**GitHub/Colab v2:** setup tự clone nhánh `feature/train-model` vào thư mục riêng, cài môi trường và phục hồi snapshot có hash. Nếu Colab yêu cầu restart sau cài thư viện, restart session rồi Run all lại. Không mở notebook cũ trong Drive để lấy kết quả chính thức.'
    if name.startswith('02'):
        n.cells.append(md('## Đối chiếu Colab với CPU reference\n\nCùng dữ liệu, code, split, seed và cấu hình. Tolerance RMSE 5% chỉ là ngưỡng kiểm tra kỹ thuật, không phải kiểm định thống kê. Không chọn lại model theo kết quả so sánh test.'))
        n.cells.append(code('''reference_path = ROOT / 'models/reference_experiment.json'
if IN_COLAB and reference_path.exists():
    from src.models.compare_runs import compare_runs
    from src.models.experiment import save_json
    comparison = compare_runs(ARTIFACT_DIR, ROOT)
    save_json(REPORT_DIR / 'reference_comparison.json', comparison)
    display(pd.Series({key: value for key, value in comparison.items() if key != 'metrics'}))
    display(pd.DataFrame(comparison['metrics']))
    import zipfile
    export_path = Path('/content') / f"fpt-colab-{result['run_id']}.zip"
    with zipfile.ZipFile(export_path, 'w', zipfile.ZIP_DEFLATED) as archive:
        for folder in [ARTIFACT_DIR, REPORT_DIR]:
            for path in folder.rglob('*'):
                if path.is_file():
                    archive.write(path, path.relative_to(ROOT).as_posix())
    print('Result bundle:', export_path)
else:
    print('Local reference run; Colab comparison is performed on the subsequent run.')'''))
    for cell in n.cells:
        if cell.cell_type == 'code':
            cell.outputs = []
            cell.execution_count = None
    nbf.validate(n)
    nbf.write(n, p)

eda = nbf.v4.new_notebook(cells=[
    md('''# EDA cổ phiếu FPT — snapshot v2

Khảo sát chất lượng nguồn, giá điều chỉnh, phân phối lợi suất và tương quan đặc trưng. Đây là mô tả hậu nghiệm sau lượt train đã khóa; không dùng test 2025 để tuning. Tương quan không phải quan hệ nhân quả.'''),
    code(setup),
    md('## 1. Chất lượng và phạm vi dữ liệu'),
    code('''features, labels, metadata = load_data(ROOT)
raw = pd.read_csv(ROOT / 'data/raw/FPT.VN_raw.csv', parse_dates=['Date'])
excluded = pd.read_csv(ROOT / 'data/processed/FPT.VN_excluded_rows.csv')
display(pd.Series({key: metadata[key] for key in ['raw_rows', 'zero_volume_excluded', 'invalid_candle_excluded', 'eligible_rows', 'warmup_rows', 'feature_rows', 'labeled_rows']}))
display(excluded['Reason'].value_counts().rename_axis('reason').to_frame('rows'))
print('Raw dates:', raw.Date.min(), raw.Date.max())
print('Positive-volume observations are not independently verified HOSE sessions.')'''),
    md('## 2. Giá và lợi suất theo thời gian'),
    code('''fig, axes = plt.subplots(2, 1, figsize=(12, 7), sharex=True)
axes[0].plot(features['Date'], features['Close'], color='#2563eb')
axes[0].set(ylabel='Adjusted close (VND)', title='FPT adjusted historical close')
axes[1].plot(features['Date'], features['Log_Return'] * 100, color='#64748b', linewidth=.7)
axes[1].set(ylabel='Log return x 100', xlabel='Observed date')
fig.tight_layout()
plt.show()'''),
    md('## 3. Phân phối lợi suất và tỷ lệ tăng/giảm'),
    code('''masks = split_masks(labels)
rows = []
fig, ax = plt.subplots(figsize=(11, 4))
for name, mask in masks.items():
    values = labels.loc[mask, TARGET_COLUMN]
    rows.append({'split': name, 'n': len(values), 'mean': values.mean(), 'std': values.std(),
                 'up': int((values > 0).sum()), 'down': int((values < 0).sum()), 'neutral': int((values == 0).sum())})
    ax.hist(values * 100, bins=45, density=True, histtype='step', linewidth=1.5, label=name)
display(pd.DataFrame(rows))
ax.set(xlabel='Target log return x 100', ylabel='Density', title='Historical distributions; test shown for description only')
ax.legend()
plt.show()'''),
    md('## 4. Tương quan trên train'),
    code('''corr = labels.loc[masks['train'], FEATURE_COLUMNS].corr()
fig, ax = plt.subplots(figsize=(10, 9))
image = ax.imshow(corr, vmin=-1, vmax=1, cmap='coolwarm')
ax.set_xticks(range(len(FEATURE_COLUMNS)), FEATURE_COLUMNS, rotation=90)
ax.set_yticks(range(len(FEATURE_COLUMNS)), FEATURE_COLUMNS)
ax.set_title('Feature correlation on training history only')
fig.colorbar(image, ax=ax, label='Pearson correlation')
fig.tight_layout()
plt.show()'''),
    md('''## Điều cần kiểm chứng tiếp

- Đối soát lịch giao dịch và corporate actions với nguồn độc lập.
- Các feature cùng nhóm return/SMA có thể trùng thông tin; kiểm chứng bằng ablation trên development.
- Phân phối thay đổi giữa các giai đoạn; một split lịch sử chưa đủ chứng minh tổng quát hóa.
- Volume bằng 0 và OHLC lỗi đã được cách ly, không khẳng định toàn bộ là ngày nghỉ.'''),
])

demo = nbf.v4.new_notebook(cells=[
    md('''# Demo FPT v2 — dùng đúng manifest

Notebook minh họa inference offline từ artifact v2. Ứng dụng UI sử dụng HTTP API nằm tại `src/app/streamlit_app.py`. Không load tên alias cũ, không tạo backtest giao dịch hoặc khuyến nghị mua/bán.'''),
    code(setup),
    code('''from src.models.inference import ModelService
service = ModelService(ROOT)
print('Run:', service.manifest['run_id'])
print('Model thắng validation:', service.manifest['selection']['selected_model'])
print('Model ML mặc định để demo:', service.default_model)
display(pd.DataFrame(service.manifest['metrics']))'''),
    md('## Lịch sử giá điều chỉnh'),
    code('''history = service.features.tail(252)
fig, ax = plt.subplots(figsize=(12, 4))
ax.plot(history['Date'], history['Close'], color='#2563eb')
ax.set(xlabel='Observed date', ylabel='Adjusted close (VND)', title='FPT snapshot — historical adjusted prices')
fig.tight_layout()
plt.show()'''),
    md('## Dự báo một quan sát kế tiếp\n\nGiá dữ liệu cuối là giá trong snapshot, không phải giá thị trường trực tiếp. Chưa có lịch HOSE xác minh nên không tự gán ngày đích.'),
    code('''import ipywidgets as widgets
from IPython.display import clear_output
selector = widgets.Dropdown(options=list(service.manifest['models']), value=service.default_model, description='Model:')
output = widgets.Output()
def render(change=None):
    with output:
        clear_output(wait=True)
        prediction = service.predict(selector.value)
        display(pd.Series(prediction))
selector.observe(render, names='value')
display(selector, output)
render()
assert service.predict('Zero-Return')['predicted_log_return'] == 0.0
print('Inference smoke check passed.')'''),
    md('''## Kịch bản API/UI

1. Chạy `python -m uvicorn src.api.main:app --port 8000`.
2. Thử Swagger ở `http://127.0.0.1:8000/docs` với `{"model":"LSTM"}`.
3. Chạy `python -m streamlit run src/app/streamlit_app.py` và so sánh LSTM, Train Mean, Zero-Return.

LSTM là model ML dùng demo, không được gắn nhãn thắng toàn bộ vì Train Mean có RMSE validation thấp hơn.'''),
])
for name, n in [('01_eda_fpt.ipynb', eda), ('04_demo_fpt_dashboard.ipynb', demo)]:
    n.metadata.kernelspec = {'display_name': 'Python 3 (ipykernel)', 'language': 'python', 'name': 'python3'}
    nbf.validate(n)
    nbf.write(n, r / 'notebooks' / name)
print('Four v2 notebooks prepared.')
