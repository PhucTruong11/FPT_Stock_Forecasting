const {chromium} = require('C:/Users/truon/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const {pathToFileURL} = require('url');
const path = require('path');
const sharp = require('C:/Users/truon/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
(async () => {
  const browser = await chromium.launch({headless: true, executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'});
  const page = await browser.newPage({viewport: {width: 1440, height: 1100}});
  await page.route('https://**/*', route => route.abort());
  await page.route('http://**/*', route => route.abort());
  for (const name of ['02_train_deep_learning_fpt', '03_evaluate_fpt_benchmark']) {
    const base = path.resolve('.cache/notebook-preview', name);
    await page.goto(pathToFileURL(base + '.html').href, {waitUntil: 'load'});
    await page.screenshot({path: base + '.png', fullPage: false});
    process.stdout.write(name + ': ' + JSON.stringify(await page.locator('body').evaluate(el => ({height: el.scrollHeight, width: el.scrollWidth}))) + '\n');
  }
  await browser.close();
  await sharp('docs/assets/pipeline.svg').png().toFile('.cache/notebook-preview/pipeline.png');
})().catch(e => { process.stderr.write(String(e)); process.exitCode = 1; });
