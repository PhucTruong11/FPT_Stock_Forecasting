import json
import os
import sys
from pathlib import Path

root = Path.cwd()
for key, relative in [('JUPYTER_RUNTIME_DIR', '.cache/jupyter-runtime'),
                      ('IPYTHONDIR', '.cache/ipython'), ('MPLCONFIGDIR', '.cache/matplotlib')]:
    path = root / relative
    path.mkdir(parents=True, exist_ok=True)
    os.environ[key] = str(path)
os.environ['JUPYTER_PATH'] = str(root / '.cache/jupyter')
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
kernel = root / '.cache/jupyter/kernels/fpt-review'
kernel.mkdir(parents=True, exist_ok=True)
(kernel / 'kernel.json').write_text(json.dumps({
    'argv': [sys.executable, '-m', 'ipykernel_launcher', '-f', '{connection_file}'],
    'display_name': 'FPT review', 'language': 'python',
}), encoding='utf-8')
import nbformat
from nbclient import NotebookClient

for name in sys.argv[1:]:
    path = root / 'notebooks' / name
    notebook = nbformat.read(path, as_version=4)
    print('Executing', name, flush=True)
    client = NotebookClient(notebook, timeout=1200, kernel_name='fpt-review',
                            resources={'metadata': {'path': str(root)}})
    client.on_cell_start = lambda **kw: print('Cell', kw['cell_index'], 'started', flush=True)
    try:
        client.execute()
    finally:
        nbformat.write(notebook, path)
    print('Saved executed notebook', name, flush=True)
